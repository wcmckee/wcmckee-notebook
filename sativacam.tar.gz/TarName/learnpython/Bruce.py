# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <markdowncell>

# Bruce's Notebook

# <codecell>


print ('Bruce\'s notebook')
       

# <codecell>


print '''This is a multi-line
print statement, also it's possibly going to
handle apostrophies without a backslash?'''

# <codecell>

h = 'hello'
w = 'world'
print (h + ' ' + w)

# <codecell>

a, b = 0, 1
while b < 200:
     print b
     a, b = b, a+b

# <codecell>

print(range(5))

# <codecell>

%%ruby
puts 'hello'

# <codecell>

for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            print n, 'equals', x, '*', n/x
            break
    else:
        # loop fell through without finding a factor
        print n, 'is a prime number'

# <codecell>


# <codecell>

import random

# <codecell>

random.randint(0,50)

# <codecell>

random.division

# <codecell>

def prime(l):
    for n in range(2, l):
        for x in range(2, n):
            if n % x == 0:
                break
        else:
            # loop fell through without finding a factor
            print n,

# <codecell>

prime(200)

# <markdowncell>

# note from william: you are not making an array here - it's a list. 
# fixed :) 

# <codecell>

mylist = ['spam','eggs','ham',100,102]
mylist

# <codecell>

print (mylist[:2], mylist[2:])

# <codecell>

print (mylist[-2:])

# <codecell>

name="bruce kingsbury"
print name
print name.title()
print name.upper()

# <codecell>

shout="IT IS QUITE RUDE TO TYPE IN ALL CAPITAL LETTERS"
print shout.lower()

# <codecell>

print ('this\nwill\tbe\nthree\tlines')

# <codecell>

print(undefined)

# <codecell>

print 

# <markdowncell>

# Some great work Bruce. I would explore more keywords and modules. You may be interested in some sysadmin python modules and such

# <codecell>

import sys

# <codecell>

sys.hexversion

# <codecell>

sys.version

# <codecell>

sys.copyright

# <codecell>

import os

# <codecell>

os.system('nmap')

# <codecell>

f = os.popen('date')
now = f.read()
print "Today is ", now

# <codecell>

import subprocess
subprocess.call(["ls", "-l", "/home"])

# <codecell>

p = subprocess.Popen(["ls", "-l", "/etc/resolv.conf"], 
stdout=subprocess.PIPE)
output, err = p.communicate()
print "*** Running ls -l command ***\n", output

# <codecell>

p = subprocess.Popen(["ping", "-c", "10", "http://artcontrol.com"], stdout=subprocess.PIPE)
output, err = p.communicate()
print  output

# <codecell>

cmdping = "ping -c4 www.artcontrol.me"
p = subprocess.Popen(cmdping, shell=True, stderr=subprocess.PIPE)
while True:
    out = p.stderr.read(1)
    if out == '' and p.poll() != None:
        break
    if out != '':
        sys.stdout.write(out)
        sys.stdout.flush()
 

# <codecell>


