# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <markdowncell>

# note from william.
# oh no. seems you forgot to save! Remember to click File -> save. Partly my own fault for not showing people/doing it myself for you at the end of the session.

# <codecell>

print 'hello world'

# <codecell>

5 * 5

# <codecell>

print "I still want to learn how to python my way through life"

# <codecell>

10 - 5

# <codecell>

print "Goodbye world!"

# <codecell>

print "I still want to learn how to use this wriggly format of writing and getting it written"

# <codecell>

x = 'what a way to go!'

# <codecell>

    

# <codecell>

x * 25

# <codecell>

5 * 5

# <codecell>

4 - 20

# <codecell>

y = 50

# <codecell>

y * 20

# <codecell>

'Well, I forgot to save my statting lesson - so I had better save my progress this time'

# <codecell>

y = 10   

# <codecell>

'hullo there beautiful'

# <codecell>

getinput('testing!')

# <codecell>

def getinput(stringname):
    mylist.append(stringname)
    return stringname

# <codecell>

getinput('hullo there gorgeous!')

# <codecell>

mylist = []

# <codecell>

def getinput(stringname):
    mylist.append(stringname)
    return stringname

# <codecell>

getinput('hullo there!')

# <codecell>

print mylist

# <codecell>

mylist.append(memory)my

# <codecell>

mylist.append('anything will do')

# <codecell>

mylist[0]

# <codecell>

mylist.sort()

# <codecell>

import random 

# <codecell>

mylist.remove('hullo there!')

# <codecell>

random.randint(2,10)

# <codecell>


random.randint(1,8)

# <codecell>

x = random.randint(2,10)

# <codecell>

print x

# <codecell>

x = random.randint(4,9)

# <codecell>

x = random.randint(2,10)

# <codecell>

print x

# <codecell>

x = random.randint(12,16)

# <codecell>


import random

# <codecell>

# Tuples

# <codecell>

colours = ( 'red', 'green', 'blue')
print("The first colour is: " + colours [0])


# <codecell>

print("\nThe available colours are:")
for colour in colours:
   print("- " + colour)

# <codecell>

def thank_you(name):
    print("\nYou are doing such good work, %s!"  % name)
    print("Thank you for feeding me this week.")
    
    thank_you('Joel')
    thank_you('Tristram')
    thank_you('Egburt')
    
    

# <codecell>

def show_students(students, message):
    #print out a message,and then a list of students.
    print (message)
    for student in students:
        print()
        #These last two items haven't wanted to print!!

# <codecell>

#Back again - trying loops

message = "Hulllo!"

for letter in message:
    print(letter) 

# <codecell>

# Whoooopee - this one worked!

# <codecell>

message = "what lovely eyes you have!"
message_list = list(message)
print(message_list)

# <codecell>

#it seems like a few things are sticking in my brain!

# <codecell>

message = "Hello beautiful!"
first_three = message[:3]
last_three = message[-3:]
print(first_three, last_three)

# <markdowncell>

# #It does work!

# <codecell>

message = "I like cats and dogs."
dog_index = message.find('dog')
print(dog_index)

# <codecell>

message = "I like cats and dogs, but I would much rather own a dog."
dog_index = message.find('dog')
print(dog_index)

# <codecell>

message = "I like cats and dogs, but I'd much rather own a dog."
last_dog_index = message.rfind('dog')
print(last_dog_index)

