# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

print 'hello'

# <codecell>

def my_func(str_p, num_p):
    return str_p + str(num_p)

# <codecell>

my_func('Your age is :',32)

# <codecell>

9/0

# <codecell>

try:
    print 9/0
except Exception, why:
    print why
    

# <codecell>

def multiply(num1, num2):
    return '%d x %d = %d' % (num1, num2, num1*num2)

print multiply(10,23)

# <codecell>

def divide(num1, num2):
    return '%d/%d = %f'%(num1,num2,float(num1)/num2)

print divide(50,40)

# <codecell>

10.0/40

# <codecell>


# <codecell>


