# IPython log file

import random
get_ipython().magic(u'logstart')
