import re
import random

blahnum = raw_input('splitnum:')
strnnow = raw_input('string now')
splitnum = re.split(blahnum, strnnow)
print(splitnum)
numbz = random.randint(0,8)

for i in range(5):
     print numbz
     numbz + 1
     print numbz
ranbz = random.randint(0,20)
rannum = random.choice(splitnum)
print rannum * ranbz
blahsub = re.split(blahnum, strnnow)

print blahsub
