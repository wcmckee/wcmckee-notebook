# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <headingcell level=1>

# wcmckee python notebook

# <codecell>

print  'hello worl'

# <codecell>

print 5 + 5

# <codecell>

x = 'Hi Tony!'

# <codecell>

print x

# <codecell>

from random import randint as ri

# <codecell>

ri(0,20)

# <codecell>

newlist = ['hello', 'test', 'number']

# <codecell>

newtuple = ('hello', 'google')

# <codecell>

cat = {'teewfewhtwertjygfgfdgesting': 'omg', 'blah': 5}

# <codecell>

print cat.setdefault('testing')

# <codecell>

def upstr(mystring):
    upstrn = mystring.upper
    return upstrn()

# <codecell>

upstr('testing one two three')

# <codecell>

def cent(p1, p2, p3 = 'fred'):
    return cent

# <codecell>

cent('hello', 'test')

# <codecell>

h = 'test'

# <codecell>

for h in range(5):
    print h
    print 'test'

# <codecell>

import random

# <headingcell level=2>

# wcmckee. Notes on Python

# <codecell>

import sys

# <codecell>

import os
import subprocess
import os.path

# <markdowncell>

# We got IPython Notebook running on all the machines at the cafe. 
# It connects to the raspberry pi. There is a git repo that I have connected to 
# github - hamipy. 
# On Wednesday I plan to get everyone that wants to use the notebook. Teaching git would
# be worth it also.
# I showed git to many people at unity classes but it would be even better to show to the python class. 
# I will be interested in seeings the numbers for this week - 
# So the plan for this week: 
# - git
# -ipython notebook
# - ??

# <markdowncell>

# During the first class we had about 12 people show up. It was a mixture of beginners and advance. Majority of the beginners were from Hamilton PC computer club. I had several members of WLUG attend - including the vice president. 
# With so many people showing up I was very overwelmed. I didn't have the notebooks setup but i encourged people to use the ipython. Some peope choose to write in a text document and run. Sadly the internet at the cafe had reset eariler in the day - this caused problems with the connection. 

# <markdowncell>

# Tonight I had my 2nd python class. We had about 8 people this time. Less than last week - but i felt the place was still very crowded - and hot. 
# I had asked Bruce about perhaps setting up outside with laptops. Most people have laptops so we could setup desks and laptops outside. It just gets too hot inside. 
# For people that don't have a laptop - they have two linux laptops - hp. They run Puppy Linux but the OS that they use doesn't really matter since we will just be using the pi notebook or ssh.
# I could also setup my laptops with this also. 
# I brought along two of my laptops but they were not used. Next week ill bring them again, just in case. 
# It would be good to do some 1 on 1 (or small groups) with some of the kids. They ask Bruce for the laptops but he tends to say no. I'm sure he would say yes if they agreed to sit down with me and work through some python exercises

# <markdowncell>

# next week i plan on having a more structued class. We need a break for 15 - 20 mins. At the start of the class I plan on doing a demo. Maybe show people about creating .py files and running them. Many people are just working down ipython notebook and running the same print hello.
# Show more of the basics of ipython - different text, SAVE, 

# <markdowncell>

# setup cron job to push at midnight. 
# add to save a pop up that asks for commit message 

# <markdowncell>

# ask what git repo you want to edit and open it
# 
# go to website - opens login - see a list of git repos that you have access to. Click and opens up repo.

# <markdowncell>

# everyones station could have ipython notebook running on half. Otherwise have two terminals open. First ina text doc - other ipython. The terminals will have screen on them with me controlling it (or bruce)
# Will get people outside with their laptops and they can just connect to the notebook over network. This means they wont need to worry about the OS on their system. I am not going to help anyone with Windows problems, they can do everything on the pi

# <markdowncell>

#  It's good I have started using markdown more. I should keep this going as i don't write like i use to but i don't like to write blog posts. I really just want to archieve my blogs and work on something fresh. I think treating the ipython notebook as a blog could suit me well. Lets see how it goes.

# <markdowncell>

# Run bash in ipython (danger danger!)

# <markdowncell>

# control raspberry pi lights from python

# <headingcell level=3>

# week 3 thoughts

# <markdowncell>

# last night i had my third python class. sadly only three people showed up (not including Bruce).
# I decided to setup on the lawn outside the computer room. This worked well as it was a nice evening and it was too hot inside. 
# Being outside meant we attracted some local teenagers over that we were able to show some Python to. 
# Toara was one who made a notebook and wrote a little code. 
# When starting people off I get them to use IPython Notebook and create a new Notebook, renaming it too thier name. Since I am awful with names I can just reference the notebook. 
# Tony also did excellent work with dict and creating functions.
# John sadly did some work but didn't save. He is still understanding strings I believe but can't comment due to not saving. 
# Ian and John worked away together and I hanged out with Bruce. We walked accross to the skatepark and then went back inside the cafe. 
# The normal afterschool kids filled the cafe and were playing Urban Terror. I've loaded the computers with some Humble Bundle games to play. They don't run well and freeze often. FTL works fine but Airforte doesn't. 
# It would be great to get some better machines and we could put Steam on the machines. 
# Anyway, lets see who shows for next weeks Python class

# <codecell>

%%bash
cp -b /var/www/install6 /home/pi/learnpython


# <codecell>

def chandir(dirmove):
    changed = os.chdir(dirmove)
    return changed
    print os.curdir

# <codecell>

chandir('/home/pi/learnpython')

# <codecell>

%%bash
git add .
git commit -m ('notes for week 3 added')

# <codecell>

%%bash
git push origin

# <markdowncell>

# This is likely wrong

# <codecell>

ls

# <codecell>

sys.getsizeof('pi')

# <codecell>

sys.getfilesystemencoding()

# <markdowncell>

# how about it does a git add commit after each save and a push at midnight

# <codecell>

import subprocess

# <codecell>

subprocess.call('ls')

# <codecell>

def cmdchk(ls):
    check = subprocess.check_output(ls)
    return check

# <codecell>

docmd = cmdchk('ls')

# <codecell>

listdoc = []

# <codecell>

for d in docmd:
    print d
    listdoc.append(d)
    

# <codecell>

print listdoc

# <codecell>

listdoc.reverse()

# <codecell>

listdoc.count('y')

# <codecell>

revnow = listdoc.count('y')

# <codecell>

print revnow

# <codecell>

print listdoc

# <codecell>

subprocess.check_output('ping', 'artcontrol.me')

# <codecell>

subprocess.sys.copyright

# <codecell>


# <codecell>

os.fork()

# <codecell>

myenv = os.environ

# <codecell>

print myenv.items

# <codecell>

import random

# <codecell>

samp = random.sample(listdoc, 9)

# <codecell>

print samp

# <codecell>

samp.index('c')

# <codecell>

import string

# <codecell>

string.join(samp)

# <codecell>

strsamp = string.joinfields(samp)

# <codecell>

string.lower(strsamp)

# <codecell>

string.zfill(strsamp, 0)

# <codecell>

string.split(strsamp, ' ')

# <codecell>

string.strip(strsamp, 'i ')

# <codecell>

import time

# <codecell>

time.localtime()

# <codecell>

time.time()

# <codecell>

time.gmtime()

# <codecell>

time.asctime()

# <codecell>

time.gmtime()

# <codecell>

time.timezone

# <codecell>

curtime = time.ctime()

# <codecell>

print curtime

# <codecell>

strcurtime = string.split(curtime, ' ')

# <codecell>

strcurtime

# <codecell>

listcurtime = list(strcurtime)

# <codecell>

listcurtime.append('test')

# <codecell>

print listcurtime

# <codecell>

str(listcurtime)

# <codecell>

incurtime = (listcurtime.index('Mar'))

# <codecell>

listcurtime[incurtime]

# <codecell>

listsamp = listcurtime + samp

# <codecell>

newlistsame = list(listsamp)

# <codecell>

newlists

# <codecell>


