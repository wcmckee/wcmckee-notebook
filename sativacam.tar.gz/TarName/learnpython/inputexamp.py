myname = raw_input('what is your name: ')
print ('Your name is ' + myname)
