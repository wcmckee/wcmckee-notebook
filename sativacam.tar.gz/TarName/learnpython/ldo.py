import math

def spiro(t, radius, nrsteps, mul) :
    stepsize = 2 * math.pi * radius * mul / nrsteps
    for i in range(0, nrsteps) :
        t.fd(stepsize)
        t.left(360 / nrsteps * mul)
    #end for
#end spiro

