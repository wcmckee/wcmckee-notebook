# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

import xlrd

# <codecell>

import xlwt
import random

# <codecell>

shename = 'hello world'
thename = 'what number?'
savename = 'exfceldoc' 
fullsave = savename + '.xls'

# <codecell>

#shename = raw_input('What to add: ')
#thename = raw_input('name of worksheet: ')
#savename = raw_input('save file as: ')
#fullsave = savename + '.xls'

# <codecell>

whx = random.randint(5,10)

# <codecell>

wb = xlwt.Workbook(encoding = 'ascii')
ws = wb.add_sheet(shename)
ws.write(whx, whx, label = thename)

for n in range(whx):
    ws.write(n, n, label=n)
wb.save(fullsave)

# <codecell>

writebook = xlrd.open_workbook(fullsave)

print writebook.sheet_names()

# <codecell>

firstsheet = writebook.sheet_names()[0]

# <codecell>

writesheet = writebook.sheet_by_name(firstsheet)
num_rows = writesheet.nrows - 1
curr_row = -1

while curr_row < num_rows:
	curr_row += 1
	row = writesheet.row(curr_row)
	print row

# <codecell>

test_rows = writesheet.number
print test_rows

# <codecell>

writesheet.cell(6,5)

# <codecell>


# <codecell>


# <codecell>


# <codecell>


# <codecell>


