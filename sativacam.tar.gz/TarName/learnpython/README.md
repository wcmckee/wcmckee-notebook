  =============
  =============
 - learnpython -
 ===============
 ===============
 ===============

Python program and notebook for learning python.
Code is under MIT.

Notebook can be viewed at http://nbviewer.ipython.org/urls/raw2.github.com/hamilpy/learnpython/master/learnpy.ipynb?create=1
Experiment notebook can be at http://nbviewer.ipython.org/github/hamilpy/learnpython/blob/experiment/learnpy.ipynb?create=1

learnpy

IPython Notebook created for the weekly python classes I've started. 

Today we got IPython Notebook running on all the machines at the cafe. 
It connects to the raspberry pi. There is a git repo that I have connected to 
github hamilpy. 
On Wednesday I plan to get everyone that wants to use the notebook. Teaching git would
be worth it also.
I showed git to many people at unity classes but it would be even better to show to the 
internet cafe. 
I will be interested in seeings the numbers for this week - 
So the plan for this week: 
- git
-ipython notebook
- ??

