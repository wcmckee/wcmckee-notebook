# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <headingcell level=3>

# Learn Python

# <markdowncell>

# Print a string

# <codecell>

import random

import sys
import os
import socket
import time
hosName = (socket.gethostname())
socket.getaddrinfo('74.50.51.32' , 9999)

# <codecell>

socket.getservbyport(80)

# <codecell>

socket.socketpair(

# <codecell>

curtimez = time.strftime('%c')

# <codecell>

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name
port = 12345                # Reserve a port for your service.
s.bind((host, port))        # Bind to the port

s.listen(5)                 # Now wait for client connection.
while True:
   c, addr = s.accept()     # Establish connection with client.
   print 'Got connection from', addr
   c.send('Thank you for connecting')
   c.close()                # Close the connection

# <codecell>

addrinfos = raw_input('Website to get ip: ')

# <codecell>

sitesoc = socket.getaddrinfo(addrinfos, 80)

# <codecell>

eleone = sitesoc[0]

# <codecell>

print eleone

# <codecell>

elz = eleone[4]

# <codecell>

print elz[0]

# <codecell>

len(sitesoc)

# <codecell>

ipstr = str(elz[0])

# <codecell>

greet = ('Hello ' + hosName + ' currently it is ' + curtimez + ' IP address: ' + ipstr)

# <codecell>

print greet

# <codecell>

print ('hello world!')

# <markdowncell>

# Some basic math

# <codecell>

print (3 * 5)

# <markdowncell>

# Variables

# <codecell>

x = ('Hamilton Computer Club! ')

# <codecell>

print x

# <markdowncell>

# Add some math into that

# <codecell>

print x * 6

# <codecell>

i = ('bleh bleh bleh')

# <codecell>

print i

# <codecell>

upi = str.upper(i)

# <codecell>


# <codecell>

import requests

# <codecell>


# <codecell>

print newci[raci]

# <codecell>

print upi

# <codecell>

print upi + i

# <markdowncell>

# modules are fun

# <codecell>

import random

# <codecell>

newRand = random.randint(0,666)

# <codecell>

upi * newRand

# <codecell>

import requests

# <markdowncell>

# I used requests to get website data

# <codecell>

newSite = requests.get('http://tlcxpress.ac.nz/tlc-website/notices/')

# <codecell>

newFile = open('site','w')

# <codecell>

newFile.close()

# <codecell>

import os

# <codecell>

getHost = os.path

# <codecell>

for d in getHost:

# <codecell>


# <codecell>

import antigravity

# <codecell>

antigravity.webbrowser.

# <codecell>

from __future__ import braces

# <codecell>

import antigravity

def main():
    antigravity.webbrowser.subprocess

if __name__ == '__main__':
    main()

# <codecell>

main()

# <codecell>

print main()

# <codecell>


