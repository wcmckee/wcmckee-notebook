# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <headingcell level=3>

# Hamilton Computer Club 

# <markdowncell>

# newmin = {'mats': 'fibre up and running!', 'changing name to Hamilton Computer Club', 'investing into kiwibank 30 day saving', 'what was achieved at the store', 'more content on website', 'talk about/show how to blog', 'name badges', 'list of members', 'mailing list', 'naming system', 'do we want a motion?', 'name badges - what to do with them?', 'discussion at next meeting regarding name badges', 'we have a box of name badges', 'does anyone else have', 'reimburse for payments - bruce', '20 dollar for 1 gig topup - bruce', treasure report', 26, 'members', 4, 'sub', 15.90, expersnces', 100, 'stall', 'printing, 50, 'for, 4, 'printing', 20, 'bank balance', 'bills to be paid', 180.07, 'move that the finacial be moved', 'passed', 'tony missed appliances', 'leaving brunces rant out of the mins', 'talking about testing equipment', 194.07, 'corrosponse', 'moved it, ammend it', 'bruce move report', 'all aye', 'rod', 'further corr with clubs and crea show', 'knowing the arrangments', 'any emails from people', 'any website hits?', 'join via website', 'on the os, input only allowed single word', 'single names were fine', 'very ammusing', 'windows, linux', 'mention getting email address', 'general business', 'all the followup', 'finacial', 'inward', 'one person applying via website', 'applications', 'manually send email', 'did the person leave a name', 'its only tk!', 'inward', 'v in hospital till 20th', 'v is very busy', 'newsletter!', 'giveup, go to blogs', 'BLOGS', 'url for the blog', 'website to do rss', 'add json object', 'no', 'if i can find a way of doing it', 'wp-api', 'decide the officers', 'treasural', 'understudy', 'william keen to be treasure undersudy', 'working on mins', 'tony will assist understudy', 'live blogging!', 

# <codecell>

import random

# <codecell>

random.randint(

