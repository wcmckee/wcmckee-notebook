# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

import os
import os.path
import tarfile
import datetime
import hashlib

class Backup(object):
    # memorize our previous back ups so that we don't over back-up.
    LASTSAVED = {}
    MD5 = hashlib.md5

    def findfiles(self, *filestrings, dir_passed=os.curdir):
        for f in filestrings:
            if type(f) != type("string"):
                raise TypeError("Pass strings only")
        target_dir = os.listdir(dir_passed)
        for this in target_dir:
            for file_pattern in filestrings:
                if file_pattern in this and os.path.isfile(os.path.abspath(this)):
                    yield this
    
    def markbackup(self, backup_file):
        with open(os.path.abspath(backup_file)) as f:
            print(self.MD5(bin(f.read())))

if __name__ == "__main__":
    app = Backup()
    for f in app.findfiles('bac'):
        app.markbackup(f)
