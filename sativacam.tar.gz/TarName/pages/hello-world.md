title: Hello World
date: 2012-03-04

**Hello world**, from a *page*!
